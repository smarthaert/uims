#!/bin/bash  
######################################################################################  
# this shell script is used to send mail automatically  
# the root structure is  
#      .  
#      ./autosend.sh        -- this shell script  
#      ./attach/            -- this folder stored mail's all attachment.  
#      ./bak/               -- for backup  
#      ./log/               -- send & unsend log files  
#      ./mail/              -- mail text content, default file name './mail/mail.md'  
#      ./readme.md          -- readme file (not mandatory)  
# version: v0.1 @Aug. 4, 2013, by Guobao Jiang   
######################################################################################  
cd /home/pmdev/auto/
./serverdataback.sh
dateInfo="$(date +%Y-%m-%d-%H-%M-%S)"
attachName="attach_$dateInfo.tar.gz";
contentFile="./mail/mail.md"
toName="mayong012071@gtjas.com"
ccName="xxjsbkhfwxt@gtjas.com"
if [ -f ./mail/mail.md ]; then
    if [ ! -f ./log/send.log ];then
        touch ./log/send.log
    fi
    sendLog="./log/send.log"
    mkdir -p "./bak/mail_$dateInfo"
    fileno=`ls ./attach|wc -w`
    if [ $fileno -gt 0 ];then
        tar zcvf $attachName ./attach
        sleep 2
        rm -rf ./attach/*
        cp $attachName "./bak/mail_$dateInfo"
    fi
  
    cp ./mail/mail.md  "./bak/mail_$dateInfo"
    echo -e "   " >>$contentFile
    echo -e "------------------" >>   $contentFile
    echo -e "Note: This mail is automaticall by my server." >> $contentFile
    echo -e "admin (xxjsbadmin@gtjas.com)" >> $contentFile
    echo -e "DateRecord: $dateInfo" >> $contentFile
  
    echo -e "  " >>"$sendLog"
    echo -e "-----------------------------------" >>"$sendLog"
    echo -e "Sending mail..."  >>"$sendLog"
  
    if [ -f $attachName ];then
        mutt -s "Data backup Result $dateInfo"  -c $ccName $toName \
            -a $attachName< "$contentFile"
        echo "has attachments." >> "$sendLog"
    else
        mutt -s "Data backup Result $dateInfo"  -c $ccName $toName \
            < "$contentFile"
        echo "no attachments." >> "$sendLog"
    fi
  
    if [ $? -eq 0 ]; then
        rm -rf $attachName
        #rm -rf ./mail/mail.md   
	>./mail/mail.md
        rm -rf ./attach/*       # if success, delete all attachment files.  
        echo -e "mail was sent to $toName and cc to $ccName successully!" >> \
            "$sendLog"
    else
        rm -rf $attachName
        rm -rf "./bak/mail_$dateInfo"
        echo -e "mail sent failed! Please try again!" >>"$sendLog"
    fi
    echo -e "RecordTime:$dateInfo" >>"$sendLog"
  
else
    if [ ! -f ./log/record.log ]; then
        touch ./log/nosend.log
    fi
    echo -e "No mail contents to send!  RecordTime: $dateInfo" >>./log/nosend.log
fi
