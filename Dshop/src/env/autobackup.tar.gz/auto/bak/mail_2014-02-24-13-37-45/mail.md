this is test
   
------------------
Note: This mail is automaticall by my server.
BR// Guobao Jiang (loveaborn@foxmail.com)
DateRecord: 2014-02-24-11-08-57
   
------------------
Note: This mail is automaticall by my server.
BR// Guobao Jiang (loveaborn@foxmail.com)
DateRecord: 2014-02-24-11-10-08
   
------------------
Note: This mail is automaticall by my server.
BR// Guobao Jiang (loveaborn@foxmail.com)
DateRecord: 2014-02-24-11-14-39
-e    
-e ------------------
-e Note: This mail is automaticall by my server.
-e BR// Guobao Jiang (loveaborn@foxmail.com)
-e DateRecord: 2014-02-24-11-15-48
